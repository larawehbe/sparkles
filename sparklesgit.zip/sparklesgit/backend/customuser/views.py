from django.shortcuts import render
from rest_framework.viewsets import ViewSet, ModelViewSet
from customuser.models import CustomUser
from customuser.serializers import CustomUserSerializer


# Create your views here.

class CustomUserViewset(ModelViewSet):
    queryset = CustomUser.objects.all()
    serializer_class = CustomUserSerializer
