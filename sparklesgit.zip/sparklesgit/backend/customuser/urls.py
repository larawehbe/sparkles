from django.urls import path, include
from rest_framework.routers import SimpleRouter

from customuser.views import CustomUserViewset

router = SimpleRouter()
router.register('user', viewset=CustomUserViewset)

urlpatterns = [
    path('', include(router.urls))
]
