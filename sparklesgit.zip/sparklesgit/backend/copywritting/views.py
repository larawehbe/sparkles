from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import TemplateView
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ViewSet, ModelViewSet
import json
from copywritting.core import call_gpt3
from copywritting.forms import ContentForm
from copywritting.models import Content
from copywritting.serializers import ContentSerializer


# Create your views here.

def homePageview(request):
    return HttpResponse("hello world")


class templateHome(TemplateView):
    template_name = "copywritting/home.html"


@api_view(['POST'])
def test_post(request):
    print(request.data)
    print(request.data.keys())
    print(request.data.values())
    for k, v in request.data.items():
        print(f'key: {k}, value: {v}')
    res = call_gpt3(request.data)
    response = Response(res)
    return response


class ContentView(APIView):
    def post(self, request):
        form = ContentForm(request.data)
        if form.is_valid():
            return Response(form.data)
        else:
            return Response("didnt work:/")


class ContentViewSet(ModelViewSet):
    serializer_class = ContentSerializer

    queryset = Content.objects.all()

    def create(self, request, *args, **kwargs):
        data = request.data
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid()
        print('serialzier data: ')
        print(serializer.data)

        print(f'create: {data}')
        res = call_gpt3(data)
        serializer.data['result'] = res['result']
        c = Content(**serializer.data).save()
        return Response({'result': res})
