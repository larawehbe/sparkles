from django.db import models

# Create your models here.

CONTENTTYPE = ['Freestyle', 'Blog Post', 'Newsletter', 'Instagram Caption', 'Sales Email']
PERSONPOV = ['First person', 'Second person', 'Third person']


class Content(models.Model):
    content_type = models.CharField(default='Freestyle', max_length=256)
    details = models.TextField()
    person_pov = models.CharField(default='First Person', max_length=256)
    tone = models.CharField(default='Friendly',
                            max_length=256)  # TODO: check how to take them and make them comma separated
    gpt3_result = models.CharField(default=None, max_length=1028)
