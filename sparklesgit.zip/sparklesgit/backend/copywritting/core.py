import requests
import json
from enum import Enum

# TODO: Put the bearer token in .env file
auth_token = "Bearer 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"

openaiUrl = " https://api.openai.com/v1/completions"
moderationsUrl = "https://api.openai.com/v1/moderations"
headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer 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'
}
UNSAFE_THRESHOLD = 0.5  # 50%


class ContentType(Enum):
    FREESTYLE = 'Freestyle'
    SALESEMAIL = 'Sales Email'
    INSTAGRAMCAPTION = 'Instagram Caption'
    NEWSLETTER = 'Newsletter'
    BLOGPOST = 'Blog Post'


class PersonPOV(Enum):
    FIRSTPERSON = 'First person'
    SECONDPERSON = 'Second person'
    THIRDPERSON = 'Third person'


class ModelType(Enum):
    DAVINCI = 'text-davinci-003'
    ADA = 'text-ada-001'
    CURIE = 'text-curie-001'
    BABBAGE = 'text-babbage-001'


def freestyle_prompt(details, tone):
    prompt = f"Write  {details}. Let it feel like {tone}."
    tokens = 2000
    return prompt, tokens


def blogpost_promt(details, tone, person_pov):
    print(f'i am here')
    prompt = f"Write a blog post about {details}. Let it feel like {tone} ."
    if person_pov:
        prompt += f'Let it be written as {person_pov}.'
    tokens = 500
    print(f'returning both')
    return prompt, tokens


def instagram_caption_prompt(details, tone):
    prompt = f"Write an instagram caption about {details}. Let it feel like {tone}. Don't forget the hashtags."
    tokens = 100
    return prompt, tokens


def newsletter_prompt(details, tone, person_pov):
    prompt = f"Write a newsletter about {details}. Let it feel like {tone}. Add subject line. Let the last paragraph be a conclusion closure."
    if person_pov:
        prompt += f'Let it be written as {person_pov}.'
    tokens = 3500
    return prompt, tokens


def sales_email_prompt(details, tone, person_pov):
    prompt = f"Write a sales email about {details}. Let it feel like {tone}. Add a call to action to schedule a meeting. Don't forget the subject line and the email closure"
    if person_pov:
        prompt += f'and written as {person_pov}.'
    tokens = 500
    return prompt, tokens


def generate_per_content(content_type, details, tone, person_pov):
    print(f'choosing content type {content_type}')
    if content_type == ContentType.FREESTYLE.value:
        return freestyle_prompt(details, tone)
    if content_type == ContentType.SALESEMAIL.value:
        return sales_email_prompt(details, tone, person_pov)
    if content_type == ContentType.INSTAGRAMCAPTION.value:
        return instagram_caption_prompt(details, tone)
    if content_type == ContentType.BLOGPOST.value:
        return blogpost_promt(details, tone, person_pov)
    if content_type == ContentType.NEWSLETTER.value:
        return newsletter_prompt(details, tone, person_pov)


# TODO: Handle if no tone of voice is set
# TODO: handle one item or the last item of a list in html to be without and

def call_gpt3(form_data):
    print(form_data)
    details = form_data['details']
    tone = form_data['tone'].split(", ")
    # print(tone)
    if len(tone) >1 :
        cleaned_tones = ", ".join(tone[:-1]) + ", and " + tone[-1]
    else:
        cleaned_tones = tone[0]
    # print(cleaned_tones)
    tone = cleaned_tones
    model_type = "text-davinci-003"

    content_type = form_data['content_type']
    person_pov = form_data['person_pov'] if "person_pov" in form_data.keys() else None
    # print(person_pov)
    prompt, tokens = generate_per_content(content_type, details, tone, person_pov)
    classified_content = content_moderation(details)
    content_filter_results = content_filter(details)

    data = {"model": "text-davinci-003", "prompt": prompt, "temperature": 0.8, "max_tokens": tokens}
    res = requests.post(openaiUrl, json.dumps(data), headers=headers)
    result = res.json()
    result = result['choices'][0]['text']

    result_classification = content_moderation(result)
    result_filteration = content_filter(result)
    res = res.json()['choices'][0]['text'].replace("\n", "<br>")

    # print(res.content)
    output = {
        'result': res,
        'content_filter_result': content_filter_results,
        'result_filteration': result_filteration
    }
    return output
    # return res, prompt, model_type, content_filter_results, classified_content, result_filteration, result_classification


def content_moderation(content):
    res = requests.post(moderationsUrl, json.dumps({"input": content, "logprobs": 10}), headers=headers)
    # print(f'res of moderation filter api: {res.json()}')

    # category_scores = dict(res.json()['results'][0]['category_scores'].items(), key=lambda item: item[1]) 
    category_scores = {k: v for k, v in
                       sorted(res.json()['results'][0]['category_scores'].items(), key=lambda item: item[1])}
    unsafe_categories = []
    # print(category_scores)
    for cat, score in category_scores.items():
        if float(score) >= UNSAFE_THRESHOLD:
            unsafe_categories.append(cat)
    print(f'unsafe categories: {unsafe_categories}')
    return unsafe_categories if unsafe_categories else None


def content_filter(content, tokens=1000):
    output_expected = {
        0: 'Safe Content',
        1: 'Sensitive Content',
        2: 'Unsafe Content'
    }
    data = {"model": "content-filter-alpha", "prompt": "<|endoftext|>" + content + "\n--\nLabel:", "temperature": 0,
            "max_tokens": 1, "user": "1", "top_p": 0, "logprobs": 10}
    res = requests.post(openaiUrl, json.dumps(data), headers=headers)
    output_label = res.json()['choices'][0]['text']
    return output_expected[int(output_label)]
