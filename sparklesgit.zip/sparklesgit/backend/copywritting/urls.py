from django.urls import path, include
from rest_framework.routers import SimpleRouter

from .views import homePageview, templateHome, test_post, ContentViewSet

router = SimpleRouter()
router.register(r'sparkles', ContentViewSet)

urlpatterns = [
    path("", homePageview, name="home"),
    path("template/", templateHome.as_view()),
    path("test/", test_post),
    path("", include(router.urls))
]

