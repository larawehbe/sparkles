from django.forms import ModelForm
from copywritting.models import Content


class ContentForm(ModelForm):
    class Meta:
        model = Content
        fields = "__all__"
